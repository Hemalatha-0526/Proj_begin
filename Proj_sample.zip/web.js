/** 
** more infos: 
** https://developer.mozilla.org/de/docs/Web/API/FileReader
** https://developer.mozilla.org/en-US/docs/Web/API/File/Using_files_from_web_applications
** https://developer.mozilla.org/de/docs/Web/API/File
** https://www.html5rocks.com/en/tutorials/file/dndfiles/
*/
function fileUploader(elem) {
  const inputElem = document.querySelector("#" + elem);
  const outputElem = document.querySelector("#upload-message");
  const filereaderOutputElem = document.querySelector("#filereader-message");
  const progressBar = document.querySelector("#filereader-progress");
  const abortButton = document.querySelector("#filereader-abort");

  inputElem.addEventListener("change", function() {
    const fileList = inputElem.files[0];
    const uploadReader = new FileReader();
    
    abortButton.removeAttribute("hidden");

    outputElem.innerHTML =
      "<strong>Größe:</strong> " +
      (fileList.size / 1024 / 1024).toFixed(2) +
      " MB <br><strong>Name:</strong> " +
      fileList.name +
      "<br><strong>Dateityp:</strong> " +
      fileList.type +
      "<br><strong>Zuletzt geändert:</strong> " +
      fileList.lastModifiedDate;

    uploadReader.onloadstart = (function() {
      progressBar.value = 0;
    });

    uploadReader.onload = (function() {
      filereaderOutputElem.setAttribute("src", uploadReader.result);
      progressBar.value = 100;
      abortButton.setAttribute("hidden", "hidden");
    });
    
    abortButton.addEventListener("click", function() {
      uploadReader.abort();
      alert("Upload aborted!");
    })
       
    uploadReader.readAsDataURL(fileList);
  });
}

fileUploader("upload");
